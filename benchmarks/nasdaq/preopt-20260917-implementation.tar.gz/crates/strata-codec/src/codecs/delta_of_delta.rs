//! Second-order delta encoding for i64 streams.

use crate::codecs::StepOutput;
use crate::error::Result;
use crate::plan::StepMetadata;
use crate::stream::Stream;

pub fn encode(input: Stream) -> Result<StepOutput> {
    let values = input.into_i64()?;
    if values.is_empty() {
        return Ok(StepOutput {
            stream: Stream::I64(Vec::new()),
            meta: None,
        });
    }
    if values.len() == 1 {
        return Ok(StepOutput {
            stream: Stream::I64(values),
            meta: None,
        });
    }
    let mut out = Vec::with_capacity(values.len());
    out.push(values[0]);
    let mut prev_delta = values[1].wrapping_sub(values[0]);
    out.push(prev_delta);
    for i in 2..values.len() {
        let delta = values[i].wrapping_sub(values[i - 1]);
        out.push(delta.wrapping_sub(prev_delta));
        prev_delta = delta;
    }
    Ok(StepOutput {
        stream: Stream::I64(out),
        meta: None,
    })
}

pub fn decode(input: Stream, _meta: Option<&StepMetadata>) -> Result<Stream> {
    let dod = input.into_i64()?;
    if dod.is_empty() {
        return Ok(Stream::I64(Vec::new()));
    }
    if dod.len() == 1 {
        return Ok(Stream::I64(dod));
    }
    let mut out = Vec::with_capacity(dod.len());
    out.push(dod[0]);
    let mut prev_delta = dod[1];
    out.push(out[0].wrapping_add(prev_delta));
    for i in 2..dod.len() {
        prev_delta = prev_delta.wrapping_add(dod[i]);
        out.push(out[i - 1].wrapping_add(prev_delta));
    }
    Ok(Stream::I64(out))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_linear() {
        let v: Vec<i64> = (0..20).map(|i| 1_000 + i * 5).collect();
        let enc = encode(Stream::I64(v.clone())).unwrap();
        let dec = decode(enc.stream, None).unwrap().into_i64().unwrap();
        assert_eq!(dec, v);
    }
}
